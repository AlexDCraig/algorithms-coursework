Compile:
g++ wrestlers.cpp -o wrestlers

Run:
./wrestlers input.txt 
