PROBLEM 4
1) For insertsort:
	a) compilation 
		g++ insertsort.cpp -o insertsort
	b) running 
		./insertsort

2) For mergesort:
	a) compilation
		g++ mergesort.cpp -o mergesort
	b) running
		./mergesort

EXTRA CREDIT
1) a) Compile insertsort extra credit program:
	g++ insertsortEC.cpp -o insertsortEC	

   b) Run the program:
	./insertsortEC [int size] [char* case]
	where size is n
	case is either "best" or "worst" without quotes
	result is transcribed to insertTestEC.out

2) a) Compile mergesort extra credit program:
	g++ mergesortEC.cpp -o mergesortEC

   b) Run program:
	./mergesortEC [int size] [char* case]
	result is transcribed to mergeTestEC.out
