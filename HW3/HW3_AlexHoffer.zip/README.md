To compile:
g++ change.cpp -o change

To run:
./change

Must have amount.txt in directory
Places results in change.txt
