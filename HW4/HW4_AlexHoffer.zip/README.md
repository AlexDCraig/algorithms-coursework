To compile:
g++ activity.cpp -o activity

To run:
./activity
